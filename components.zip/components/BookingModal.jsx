import React, { useState, useEffect } from "react";
import axios from "axios";
import dayjs from "dayjs";

function BookingModal({ roomType, onClose }) {
  const [availableRooms, setAvailableRooms] = useState([]);
  const [selectedRooms, setSelectedRooms] = useState([]);
  const [form, setForm] = useState({
    full_name: "",
    phone: "",
    email: "",
    arrival_date: "",
    departure_date: "",
    total_amount: "",
    captured_image: "",
  });

  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    if (form.arrival_date && form.departure_date) {
      (async () => {
        try {
          const res = await axios.get(`https://hotel.skykode.com.ng/api/available-rooms`, {
            params: {
              arrival: form.arrival_date,
              departure: form.departure_date,
              room_type_id: roomType.id,
            },
          });
          setAvailableRooms(res.data);
          setSelectedRooms([]);
        } catch (err) {
          console.error("Room fetch error:", err);
        }
      })();
    }
  }, [form.arrival_date, form.departure_date]);

  useEffect(() => {
    if (form.arrival_date && form.departure_date && selectedRooms.length > 0) {
      const nights = dayjs(form.departure_date).diff(dayjs(form.arrival_date), "day");
      const price = roomType?.pricing?.default_price_per_night || 0;
      const total = nights * price * selectedRooms.length;
      setForm((prev) => ({ ...prev, total_amount: total }));
    }
  }, [form.arrival_date, form.departure_date, selectedRooms]);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleRoomSelect = (e) => {
    const options = e.target.options;
    const selected = [];
    for (let i = 0; i < options.length; i++) {
      if (options[i].selected) selected.push(options[i].value);
    }
    setSelectedRooms(selected);
  };

const handleSubmit = async (e) => {
  e.preventDefault();

  if (!form.full_name || !form.phone || !form.arrival_date || !form.departure_date || selectedRooms.length === 0) {
    alert("Please fill all required fields.");
    return;
  }

  // Save to localStorage
  const bookingPayload = {
    ...form,
    room_id: selectedRooms[0] || null,
    room_ids: selectedRooms,
    booking_date: new Date().toISOString().slice(0, 10),
    captured_image: form.captured_image || "",
    payment_status: "unpaid",
    amount_paid: 0,
    status: "pending",
    payment_ref: "", // will be updated after payment
  };

  localStorage.setItem("bookingData", JSON.stringify(bookingPayload));

  // Redirect to pay page
  window.location.href = "/pay";
};





  const captureImage = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.capture = "user";
    input.onchange = (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
          setForm({ ...form, captured_image: reader.result });
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  };

  if (success) {
    const message = encodeURIComponent(
      `🛎️ Hotel Booking Confirmed!\n\nName: ${form.full_name}\nPhone: ${form.phone}\nEmail: ${form.email}\nArrival: ${form.arrival_date}\nDeparture: ${form.departure_date}\nRooms: ${selectedRooms.join(", ")}\nTotal Paid: ₦${form.total_amount}\n\nThank you for booking with us!`
    );
    const whatsappUrl = `https://wa.me/2348000000000?text=${message}`;

    return (
      <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50">
        <div className="bg-white p-6 rounded-lg max-w-lg w-full animate-zoom-in">
          <h2 className="text-xl font-bold text-green-600">🎉 Booking Successful!</h2>
          <p className="mt-2 text-gray-700">We’ll reach out shortly via WhatsApp.</p>
          <div className="flex gap-3 mt-4 justify-end">
            <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600">
              Confirm via WhatsApp
            </a>
            <button onClick={onClose} className="px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700">Close</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm z-50 flex items-center justify-center px-3">
      <div className="bg-white text-gray-900 w-full max-w-md rounded-2xl shadow-xl overflow-y-auto max-h-[90vh] relative animate-zoom-in">
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 rounded-t-2xl flex justify-between items-center">
          <h2 className="text-lg md:text-xl font-semibold">Book Room - {roomType.type}</h2>
          <button onClick={onClose} className="text-white text-2xl leading-none hover:text-red-200" title="Close">&times;</button>
        </div>

        <div className="p-5 space-y-4">
          <form onSubmit={handleSubmit} className="space-y-3">
            <label className="block text-sm font-medium">Arrival & Departure Dates</label>
            <div className="grid grid-cols-2 gap-2">
              <input type="date" name="arrival_date" value={form.arrival_date} onChange={handleChange} required className="border p-2 rounded w-full" />
              <input type="date" name="departure_date" value={form.departure_date} onChange={handleChange} required className="border p-2 rounded w-full" />
            </div>

            <label className="block text-sm font-medium">Select Room(s)</label>
            <select multiple value={selectedRooms} onChange={handleRoomSelect} required className="border p-2 w-full rounded h-28">
              {availableRooms.map(room => (
                <option key={room.id} value={room.id}>Room #{room.room_number}</option>
              ))}
            </select>

            <input name="full_name" placeholder="Full Name" value={form.full_name} onChange={handleChange} required className="border p-2 w-full rounded" />
            <input name="phone" placeholder="Phone" value={form.phone} onChange={handleChange} required className="border p-2 w-full rounded" />
            <input name="email" placeholder="Email" value={form.email} onChange={handleChange} className="border p-2 w-full rounded" />

            {!form.captured_image && (
              <button type="button" onClick={captureImage} className="w-full px-4 py-2 bg-purple-600 text-white rounded">
                📷 Capture Face (Optional)
              </button>
            )}

            {form.captured_image && (
              <div className="my-2">
                <img src={form.captured_image} alt="Captured" className="w-24 h-24 object-cover rounded border" />
                <button type="button" onClick={() => setForm({ ...form, captured_image: "" })} className="text-red-600 text-xs">
                  Remove
                </button>
              </div>
            )}

            <label className="block text-sm font-medium">Total Amount (₦)</label>
            <input value={form.total_amount} readOnly className="border p-2 w-full rounded bg-gray-100 font-bold text-lg text-green-700" />

            <div className="flex justify-between">
              <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700">Cancel</button>
              <button type="submit" disabled={loading} className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                {loading ? "Booking..." : "Confirm Booking"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default BookingModal;
