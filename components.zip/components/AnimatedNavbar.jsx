import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

const menuItems = [
  "Room Booking",
  "Hall Booking",
  "Club Booking",
  "Cinema Booking",
  "Gym Booking",
  "Pool Side Booking",
  "Restaurant",
  "Canteen",
  "Bar",
];

export default function AnimatedNavbar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <nav className="bg-blue-800 text-white px-4 py-3 flex justify-between items-center sticky top-0 z-50">
        <h1 className="text-xl font-bold">Skykode Hotel</h1>
        <button
          className="md:hidden focus:outline-none"
          onClick={() => setIsOpen(!isOpen)}
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            {isOpen ? (
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            ) : (
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16M4 18h16"
              />
            )}
          </svg>
        </button>

        <ul className="hidden md:flex space-x-6">
          {menuItems.map((item) => (
            <li key={item} className="hover:underline cursor-pointer">
              {item}
            </li>
          ))}
        </ul>
      </nav>

      <AnimatePresence>
        {isOpen && (
          <motion.ul
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "tween", duration: 0.4 }}
            className="md:hidden fixed top-0 right-0 w-3/4 h-full bg-white shadow-lg z-50 p-6 space-y-6 text-blue-800 text-lg font-semibold"
          >
          {menuItems.map((item) => (
  <li key={item}>
    <button
      onClick={() => setIsOpen(false)}
      className="w-full text-left border-b pb-2 hover:text-blue-500 active:bg-blue-100 cursor-pointer py-2"
    >
      {item}
    </button>
  </li>
))}

          </motion.ul>
        )}
      </AnimatePresence>
    </>
  );
}
