import { useEffect, useState } from "react";
import axios from "axios";
import BookingModal from "./BookingModal"; // ← Make sure this file exists

function RoomTypeList() {
  const [roomTypes, setRoomTypes] = useState([]);
  const [selectedRoomType, setSelectedRoomType] = useState(null);

  useEffect(() => {
    axios
      .get("https://hotel.skykode.com.ng/api/room-types")
      .then((response) => {
        setRoomTypes(response.data);
      })
      .catch((error) => {
        console.error("Error fetching room types:", error);
      });
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-100 py-10 px-4">
      <h1 className="text-3xl font-bold text-center text-blue-800 mb-8">
        Available Room Types
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {roomTypes.map((room, index) => (
          <div key={index} className="relative group">
            {/* Animated Rainbow Border */}
            <div className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-pink-500 via-yellow-400 to-purple-500 opacity-70 blur-md group-hover:opacity-100 animate-border-spin z-0"></div>

            {/* Main Card */}
            <div className="relative bg-white shadow-xl rounded-2xl overflow-hidden transition-transform hover:scale-[1.02] z-10">
              {/* Image */}
              <div className="relative h-48 w-full bg-gray-200">
                {room.image ? (
                  <img
                    src={`https://hotel.skykode.com.ng/uploads/room-images/${room.image}`}
                    alt={room.type}
                    className="object-cover w-full h-full"
                  />
                ) : (
                  <div className="flex items-center justify-center h-full text-gray-400">
                    No Image
                  </div>
                )}
              </div>

              {/* Info */}
              <div className="p-4">
                <h2 className="text-xl font-bold text-blue-800 mb-1">
                  {room.type}
                </h2>
                <div
                  className="text-gray-600 text-sm mb-2 line-clamp-2"
                  dangerouslySetInnerHTML={{ __html: room.description }}
                ></div>

                <ul className="text-sm text-gray-700 mb-4 space-y-1">
                  <li>
                    <strong>Price:</strong> ₦
                    {room?.pricing?.default_price_per_night
                      ? Number(
                          room.pricing.default_price_per_night
                        ).toLocaleString("en-NG", {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })
                      : "N/A"}
                  </li>
                  <li>
                    <strong>Max Adults:</strong> {room.no_of_adult}
                  </li>
                  <li>
                    <strong>Max Children:</strong> {room.no_of_child}
                  </li>
                </ul>

                <button
                  onClick={() => setSelectedRoomType(room)}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-medium px-4 py-2 rounded-lg w-full transition-all"
                >
                  Book Now
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Booking Modal */}
      {selectedRoomType && (
        <BookingModal
          roomType={selectedRoomType}
          onClose={() => setSelectedRoomType(null)}
        />
      )}
    </div>
  );
}

export default RoomTypeList;
