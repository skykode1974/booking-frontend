export default function HeroHeader() {
  return (
    <header className="relative h-[70vh] bg-cover bg-center" style={{ backgroundImage: "url('/hero-hotel.png')" }}>
      <div className="absolute inset-0 bg-black bg-opacity-60"></div>

      <div className="relative z-10 flex flex-col items-center justify-center h-full text-white text-center px-4">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">Find Your Perfect Stay</h1>
        <p className="mb-6 text-lg md:text-xl">Book rooms, halls, pools, and more — the smart way</p>

        <div className="w-full max-w-3xl bg-white rounded-lg shadow-lg p-4 grid grid-cols-1 md:grid-cols-4 gap-2 text-gray-700">
          <input
            type="text"
            placeholder="Where to?"
            className="border rounded px-3 py-2 w-full"
          />
          <input
            type="date"
            className="border rounded px-3 py-2 w-full"
          />
          <select className="border rounded px-3 py-2 w-full">
            <option>1 Guest</option>
            <option>2 Guests</option>
            <option>3 Guests</option>
          </select>
          <button className="bg-blue-700 text-white px-4 py-2 rounded hover:bg-blue-800 w-full">
            Search
          </button>
        </div>
      </div>
    </header>
  );
}
